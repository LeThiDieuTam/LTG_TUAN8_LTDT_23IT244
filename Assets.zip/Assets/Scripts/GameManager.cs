
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class GameManager : MonoBehaviour
{
    [Header("Popup UI")]
    [SerializeField] private GameObject gameMenu;
    [SerializeField] private TMP_Text titleText;
    [SerializeField] private TMP_Text messageText;
    [SerializeField] private TMP_Text continueButtonText;
    [SerializeField] private TMP_Text restartButtonText;

    [Header("Scene Settings")]
    [SerializeField] private string nextSceneName = "NextScene";

    private bool popupShown = false;

    private void Start()
    {
        Time.timeScale = 1f;

        if (gameMenu != null)
        {
            gameMenu.SetActive(false);
        }
    }

    public void ShowPopup()
    {
        if (popupShown) return;

        popupShown = true;

        titleText.text = "FLIGHT COMPLETE!";
        messageText.text =
            "May bay da cham vao tuong!\nBan muon lam gi tiep theo?";

        continueButtonText.text = "CONTINUE";
        restartButtonText.text = "RESTART";

        gameMenu.SetActive(true);

        AirplaneController plane =
            FindFirstObjectByType<AirplaneController>();

        if (plane != null)
        {
            plane.StopPlane();
        }

        Time.timeScale = 0f;
    }

    public void NextScene()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(nextSceneName);
    }

    public void RestartScene()
    {
        Time.timeScale = 1f;

        Scene currentScene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(currentScene.name);
    }
}
