
using UnityEngine;

public class EnterGame : MonoBehaviour
{
    [SerializeField] private GameManager gameManager;

    private bool hasTriggered = false;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (hasTriggered) return;

        if (!other.CompareTag("Player")) return;

        hasTriggered = true;
        gameManager.ShowPopup();
    }
}
