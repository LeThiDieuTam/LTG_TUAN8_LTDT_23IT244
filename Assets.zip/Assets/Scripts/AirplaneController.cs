
using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Rigidbody2D))]
public class AirplaneController : MonoBehaviour
{
    [SerializeField] private float forwardSpeed = 3f;
    [SerializeField] private float verticalSpeed = 4f;

    private Rigidbody2D rb;
    private float verticalInput;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.gravityScale = 0f;
    }

    private void Update()
    {
        verticalInput = 0f;

        if (Keyboard.current == null)
            return;

        if (Keyboard.current.wKey.isPressed ||
            Keyboard.current.upArrowKey.isPressed)
        {
            verticalInput = 1f;
        }
        else if (Keyboard.current.sKey.isPressed ||
                 Keyboard.current.downArrowKey.isPressed)
        {
            verticalInput = -1f;
        }
    }

    private void FixedUpdate()
    {
        rb.linearVelocity = new Vector2(
            forwardSpeed,
            verticalInput * verticalSpeed
        );
    }

    public void StopPlane()
    {
        rb.linearVelocity = Vector2.zero;
    }
}
